package com.greatlearning.security.LibraryManagementSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManagementSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
