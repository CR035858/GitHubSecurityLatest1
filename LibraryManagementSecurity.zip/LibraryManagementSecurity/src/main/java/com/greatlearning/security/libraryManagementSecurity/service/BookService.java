package com.greatlearning.security.libraryManagementSecurity.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.greatlearning.security.libraryManagementSecurity.entity.Book;
@Service
public interface BookService {
	
	public List<Book> findAll();

	public Book findById(int theId);

	public void save(Book theBook);

	public void deleteById(int theId);

	public List<Book> searchBy(String name, String author);

}
